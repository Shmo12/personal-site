module.exports = {
  // -- Prismic repository GraphQL endpoint
  apiEndpoint: 'https://jchwebsite.prismic.io/graphql',
};
