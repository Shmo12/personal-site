// // In src/prismic-configuration.js
// linkResolver: function(doc) {

//     // URL for a category type
//     if (doc.type == 'category') {
//         return '/category/' + doc.uid;
//     }

//     // URL for a product type
//     if (doc.type == 'product') {
//         return '/product/' + doc.uid;
//     }

//     // Backup for all other types
//     return '/';
// }